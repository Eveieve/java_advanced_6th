create
    definer = ssg@localhost procedure delivProc(IN id varchar(20))
BEGIN
    SELECT usertbl.userID, usertbl.addr , usertbl.mobile1, usertbl.mobile2 FROM usertbl WHERE userID = id;

END;

