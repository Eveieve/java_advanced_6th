create
    definer = root@localhost procedure SP_MEMBER_LIST()
BEGIN
    -- 회원 목록 조회
    SELECT M_SEQ, M_USERID, M_PWD, M_EMAIL, M_HP, M_REGISTDATE, M_POINT
    FROM TB_MEMBER;
END;

