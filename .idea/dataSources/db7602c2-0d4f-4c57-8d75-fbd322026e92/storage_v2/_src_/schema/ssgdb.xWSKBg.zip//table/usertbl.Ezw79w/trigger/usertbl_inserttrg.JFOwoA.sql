create definer = root@localhost trigger userTbl_InsertTrg
    after insert
    on usertbl
    for each row
BEGIN
    SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '데이터의 입력을 시도했습니다. 귀하의 정보가 서버에 기록되었습니다.';
END;

