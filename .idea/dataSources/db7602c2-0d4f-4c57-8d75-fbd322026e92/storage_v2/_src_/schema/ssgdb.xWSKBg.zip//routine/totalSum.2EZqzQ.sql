create
    definer = ssg@localhost procedure totalSum()
BEGIN
    DECLARE i int;  -- 1 씩 증가하는 값
    DECLARE result int;  --  합계(정수형). 오버플로 발생시킬 예정
    DECLARE savepointResult int;  -- 오버플로 직전 의 값 저장

    DECLARE EXIT HANDLER FOR 1264    -- INT형 오버플로가 발생하면 해당 부분 수행
    BEGIN
       SELECT CONCAT('INT 오버플로 직전의 합계 --> ', savepointResult);
       -- SELECT CONCAT('1+2+3+.....+ ', i , ' = '오버플로');
    end ;

    SET i = 1;   -- i 1로 초기화
    SET result = 0; -- 합계 0 초기화

    WHILE(TRUE) DO  -- 무한루프
        SET savepointResult = result;   -- 오버플로 직전의 합을 저장하기 위해
        SET result = result + i;
        SET i = i + 1;

    END WHILE;
 END;

