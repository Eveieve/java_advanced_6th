create
    definer = ssg@localhost procedure ifelseProc(IN userName varchar(20))
BEGIN
    DECLARE
        bYear INT;

    SELECT birthYear into bYear FROM usertbl where name = userName;
    if (bYear >= 1980) THEN
        SELECT '고객님 건강보험 생애 전환 서비스 가입에 해당하지 않습니다.';
    else
        SELECT '고객님 건강보험 생애 전환 서비스 가입에 해당하오니 가입해 주시길 바랍니다.';

    END IF;
END;

