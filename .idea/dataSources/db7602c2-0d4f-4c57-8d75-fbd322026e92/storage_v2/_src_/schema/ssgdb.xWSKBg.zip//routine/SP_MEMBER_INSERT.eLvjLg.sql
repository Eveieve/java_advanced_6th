create
    definer = root@localhost procedure SP_MEMBER_INSERT(IN V_USERID varchar(50), IN V_PWD varchar(50),
                                                        IN V_EMAIL varchar(50), IN V_HP varchar(20), OUT RTN_CODE int)
BEGIN
    DECLARE v_count int;

    -- 중복사용자 예외 처리
    SELECT COUNT(m_seq) into v_count FROM TB_MEMBER WHERE m_userid = V_USERID;

    IF v_count > 0 then
        SET RTN_CODE = 100; -- 이미 존재하는 사용자 있다.
    ELSE
        INSERT INTO TB_MEMBER (M_USERID, M_PWD, M_EMAIL, M_HP) VALUES (V_USERID, V_PWD, V_EMAIL, V_HP);

        SET RTN_CODE = 200;

    END IF;
    COMMIT;

end;

