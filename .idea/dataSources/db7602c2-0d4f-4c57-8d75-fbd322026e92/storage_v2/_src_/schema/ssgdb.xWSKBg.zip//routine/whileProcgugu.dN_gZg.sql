create
    definer = ssg@localhost procedure whileProcgugu()
BEGIN
    DECLARE i int;  -- 구구단 앞자리
    DECLARE j int;  -- 구구단 뒷자리
    DECLARE str VARCHAR(100);  -- 각 단을 문자열로 저장

    SET i = 2;

    WHILE ( i  < 10) DO   -- 2단 ~9단까지
        SET str = '';
        SET j = 1;   -- 구구단 뒤 숫자   2 x 1 부터 ~ 9까지
        WHILE (j < 10) DO
               SET str = concat(str, ' ' , i , ' x ', j, ' = ', i*j );   -- 결과물 출력
               SET j = j+1;
            end while;
            SET i = i + 1;
            INSERT INTO guguTBL VALUES  (str);

    END WHILE;

END;

