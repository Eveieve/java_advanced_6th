create
    definer = ssg@localhost procedure nameTblProc(IN tblname varchar(20))
BEGIN
    SET @sqlQuery  = concat ('SELECT * FROM ' , tblname);
    PREPARE myQuery  FROM @sqlQuery;
    EXECUTE myQuery;
    DEALLOCATE PREPARE myQuery;

END;

